#!/usr/bin/python

import sys

#inout will come from STDIN 
count=0
for line in sys.stdin:
   if ( count != 0 ):
      line = line.strip()
      line = line.split(",")

      if len(line) >= 2 and  line[15] != 'NA'  :
         depd = line[15]
         day = line[3]

         print '%s\t%s' % (day, depd )

   count +=1
