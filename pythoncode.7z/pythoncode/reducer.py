#!/usr/bin/python
#Reducer.py
import sys

day_delays = {}

#Partitoner
for line in sys.stdin:
    line = line.strip()
    day, delay = line.split('\t')

    if day in day_delays :
        day_delays[day].append(int(delay))
    else:
        day_delays[day] = []
        day_delays[day].append(int(delay))

#Reducer
for day in day_delays.keys():
    ave_delay = sum(day_delays[day]) / len(day_delays[day])
    print '%s\t%s'% (day, ave_delay)
