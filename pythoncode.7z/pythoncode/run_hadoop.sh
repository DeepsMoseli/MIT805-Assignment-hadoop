#!/bin/bash

hadoop jar /usr/local/hadoop/hadoop-2.7.4/share/hadoop/tools/lib/hadoop-streaming-2.7.4.jar   -mapper mapper.py  -reducer reducer.py  -input /test/adult.csv  -output ave_age  -file mapper.py  -file reducer.py
